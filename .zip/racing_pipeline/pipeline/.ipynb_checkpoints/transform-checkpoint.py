import logging
import pyspark
from pyspark.sql import SparkSession
















def transformation(config):
    # Establish database connection
    connection = get_redshift_connection(config)
    cur = connection.cursor()
    
    # EXECUTES SPARK FUNCTIONS
    
    
    connection.close()
    