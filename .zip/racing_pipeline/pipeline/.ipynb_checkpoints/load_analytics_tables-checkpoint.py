
def load():
    pass