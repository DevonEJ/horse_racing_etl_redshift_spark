import configparser
import psycopg2
import logging

# Import relevant utility functions
from utils.connections import get_redshift_connection

from utils.run_sql import execute_sql_file

# Import relevant pipeline validation checks
from pipeline_validation_checks.count_rows import count_table_rows


# Set up logging for pipeline - all logging levels set to 'info'
logging.getLogger('pipeline_logger')


def staging(config):
    logging.warn('Starting staging tables to Redshift.')
    
    # Establish database connection
    connection = get_redshift_connection(config)
    cur = connection.cursor()
    
    # Create staging tables
    execute_sql_file('/home/workspace/racing_pipeline/sql/create_staging_tables.sql', cur)

    # Copy data from S3 to Redshift
    execute_sql_file('/home/workspace/racing_pipeline/sql/copy_to_staging_tables.sql', cur)

    # Validate that tables contain expected number of rows
    validation_dict: dict = {'staging_conditions': 12,
                             'staging_forms': 43293,
                             'staging_horse_sexes': 6, 
                             'staging_horses': 14113,
                             'staging_markets':3316,
                             'staging_odds': 410023,
                             'staging_riders': 1025,
                             'staging_runners': 44428}
                            
    count_table_rows(validation_dict, 'horse_racing.public', cur)
    
    logging.warn('Staging to Redshift complete.')

    # Close Redshift connection
    connection.close()
