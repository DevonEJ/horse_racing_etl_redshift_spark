import configparser
import psycopg2
import logging

def get_redshift_connection(config_file_path: str):
    """
    Returns a connection to a Redshift database hosted in AWS, when provided with a path to 
    configuration file holding the host, database name, username, password and port of the target
    database/cluster.
    """
    config = configparser.ConfigParser()
    config.read(config_file_path)
    conn = psycopg2.connect(f"host={config['CLUSTER']['HOST']} dbname={config['CLUSTER']['DB_NAME']} user={config['CLUSTER']['DB_USER']} password={config['CLUSTER']['DB_PASSWORD']} port={config['CLUSTER']['DB_PORT']}")
    conn.autocommit = True
    logging.warn('Redshift connection has been successfully established.')
    return conn
