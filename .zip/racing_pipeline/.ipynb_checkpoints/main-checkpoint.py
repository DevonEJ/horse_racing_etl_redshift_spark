import logging
import configparser


# Import pipeline stages
from pipeline.extract_to_staging import staging
from pipeline.transform import transformation
from pipeline.load_analytics_tables import load


# Set up logging for pipeline
logging.getLogger('pipeline_logger')


# Execute pipeline stages
def main(config):
    logging.warn('Start of pipeline.')
    staging(config)
    transformation(config)
    load(config)
    logging.warn('End of pipeline.')



if __name__ == "__main__":
    config: str = '/home/workspace/racing_pipeline/config/configuration.cfg'
    main(config)
